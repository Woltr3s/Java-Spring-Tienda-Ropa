package com.example.tiendaRopaSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaRopaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
