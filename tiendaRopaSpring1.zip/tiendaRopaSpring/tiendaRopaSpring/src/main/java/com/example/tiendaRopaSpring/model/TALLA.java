package com.example.tiendaRopaSpring.model;

public enum TALLA {
    XS, S, M, L, XL, XXL
}
