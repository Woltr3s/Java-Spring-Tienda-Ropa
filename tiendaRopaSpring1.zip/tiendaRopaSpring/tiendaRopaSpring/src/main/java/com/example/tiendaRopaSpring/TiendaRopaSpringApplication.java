package com.example.tiendaRopaSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaRopaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaRopaSpringApplication.class, args);
		//http://localhost:8080/web/usuarios
		//https://blue-shuttle-9348687.postman.co/workspace/wol3's-Workspace~d2aa5dcf-0028-4575-804b-2058bf49f75e/collection/51380743-cdc7d8ab-74f3-413c-b29b-5d3335b0f6b9?action=share&creator=51380743
	}

}
