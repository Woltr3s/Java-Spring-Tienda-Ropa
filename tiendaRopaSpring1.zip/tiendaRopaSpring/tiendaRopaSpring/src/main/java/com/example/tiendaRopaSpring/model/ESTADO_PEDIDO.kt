package com.example.tiendaRopaSpring.model

enum class ESTADO_PEDIDO {
    PENDIENTE, FINALIZADO, ENTREGADO, CANCELADO
}