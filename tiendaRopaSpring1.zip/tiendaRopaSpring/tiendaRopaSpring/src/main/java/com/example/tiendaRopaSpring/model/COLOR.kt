package com.example.tiendaRopaSpring.model

enum class COLOR {
    NEGRO, BLANCO, ROJO, AZUL, AMARILLO, VERDE
}